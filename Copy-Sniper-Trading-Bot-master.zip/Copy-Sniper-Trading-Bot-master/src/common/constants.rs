pub const INIT_MSG: &str = "Made by DEVDUDES";

// Whale selling detection threshold - emergency sell all when detecting 10+ SOL whale selling transaction
pub const WHALE_SELLING_AMOUNT_FOR_SELLING_TRIGGER: f64 = 10.0; // SOL

pub const RUN_MSG: &str = "
        RUNNING BOT.....                                                                                               
       ";
